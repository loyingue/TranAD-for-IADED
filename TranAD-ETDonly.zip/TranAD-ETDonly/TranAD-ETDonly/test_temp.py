import matplotlib.pyplot as plt
import scienceplots
print(plt.style.available)
plt.style.use(['science', 'ieee'])